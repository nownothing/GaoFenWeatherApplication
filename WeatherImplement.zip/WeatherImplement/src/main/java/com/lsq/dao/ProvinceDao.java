package com.lsq.dao;

import com.lsq.entity.Province;

import java.util.List;

public interface ProvinceDao {
    List<Province> selectAllProvince();

    List<Province> selectAllProvince1();
}
