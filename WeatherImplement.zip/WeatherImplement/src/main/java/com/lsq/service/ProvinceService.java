package com.lsq.service;

import com.lsq.entity.Province;

import java.util.List;

public interface ProvinceService {
    List<Province> findAllProvince();

    List<Province> findAllProvince1();
}
